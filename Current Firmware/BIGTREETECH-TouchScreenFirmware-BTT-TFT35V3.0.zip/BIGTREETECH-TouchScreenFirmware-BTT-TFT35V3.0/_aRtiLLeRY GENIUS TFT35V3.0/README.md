***
# BTT TFT35 V3.0 evoz3D:alien: Firmware Vx.x.27
# aRtiLLeRY GENIUS evoz3D:alien: Marlin Firmware 2.0.7.2 [wiki](https://github.com/omonge22/evoz3D/wiki/aRtiLLeRY-GENIUS#evoz3dalien-marlin-firmware-2072)
***
